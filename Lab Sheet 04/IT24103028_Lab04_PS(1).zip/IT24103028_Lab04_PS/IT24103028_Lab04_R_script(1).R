setwd("C:\\Users\\it24103028\\Desktop\\IT24103028_Lab04_PS")
getwd()

#01
branch_data <- read.table("Exercise.txt", header = TRUE,sep = ",")

#02
str(branch_data)

#03
boxplot(branch_data$Sales_X1,main="Box plot of Sales",outline=TRUE,outpch=8,horizontal=TRUE)


#04
summary(branch_data$Advertising_X2)

quantile(branch_data$Advertising_X2)

quantile(branch_data$Advertising_X2)[2]

quantile(branch_data$Advertising_X2)[4]

#
IQR(branch_data$Advertising_X2)


#05
get.outliers <- function(z) {
  q1 <- quantile(z)[2]       
  q3 <- quantile(z)[4]        
  IQR <- q3 - q1     
  
  upper_bound <- q3 + 1.5 * IQR
  lower_bound <- q1 - 1.5 * IQR
  
  print(paste("Upper Bound = ", upper_bound))
  print(paste("Lower Bound = ", lower_bound))
  print(paste("Outliers:", paste(sort(z[z<lower_bound | z>upper_bound]), collapse = ",")))
}

get.outliers(branch_data$Years_X3)
